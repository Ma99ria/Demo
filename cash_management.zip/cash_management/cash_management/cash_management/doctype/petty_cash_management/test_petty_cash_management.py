# Copyright (c) 2024, Maria Rose Xavier and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestPettyCashManagement(FrappeTestCase):
	pass
